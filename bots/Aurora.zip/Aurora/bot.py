from rlbot.agents.base_agent import BaseAgent, SimpleControllerState
from rlbot.utils.structures.game_data_struct import GameTickPacket
import numpy as np
import math
from action.default_act import DefaultAction
from agent import Agent
from obs.advanced_padder import AdvancedObsPadder
from obs.advanced_obs import AdvancedObs
from rlgym_compat import GameState
from rlgym_tools.extra_action_parsers.lookup_act import LookupAction
from numpy import array

KICKOFF_CONTROLSN = (
        11 * 4 * [SimpleControllerState(throttle=1, boost=True)]
        + 4 * 4 * [SimpleControllerState(throttle=1, boost=True, steer=-1)]
        + 2 * 4 * [SimpleControllerState(throttle=1, jump=True, boost=True)]
        + 1 * 4 * [SimpleControllerState(throttle=1, boost=True)]
        + 1 * 4 * [SimpleControllerState(throttle=1, yaw=0.8, pitch=-0.7, jump=True, boost=True)]
        + 13 * 4 * [SimpleControllerState(throttle=1, pitch=1, boost=True)]
        + 10 * 4 * [SimpleControllerState(throttle=1, roll=1, pitch=0.5)]
)

KICKOFF_NUMPYN = np.array([
    [scs.throttle, scs.steer, scs.pitch, scs.yaw, scs.roll, scs.jump, scs.boost, scs.handbrake]
    for scs in KICKOFF_CONTROLSN
])

KICKOFF_CONTROLSOL = (
            10 * 4 * [SimpleControllerState(throttle=1, boost=True)]
            + 2 * 4 * [SimpleControllerState(throttle=1, boost=True, steer=-1)]
            + 2 * 4 * [SimpleControllerState(throttle=1, jump=True, boost=True)]
            + 1 * 4 * [SimpleControllerState(throttle=1, boost=True)]
            + 1 * 4 * [SimpleControllerState(throttle=1, yaw=0.8, pitch=-0.7, jump=True, boost=True)]
            + 13 * 4 * [SimpleControllerState(throttle=1, pitch=1, boost=True)]
            + 10 * 4 * [SimpleControllerState(throttle=1, roll=1, pitch=0.5)]
            )

KICKOFF_NUMPYOL = np.array([
    [scs.throttle, scs.steer, scs.pitch, scs.yaw, scs.roll, scs.jump, scs.boost, scs.handbrake]
    for scs in KICKOFF_CONTROLSOL
])

KICKOFF_CONTROLSOR = (
            + 7 * 4 * [SimpleControllerState(throttle=1, boost=True)]
            + 6 * 4 * [SimpleControllerState(throttle=1, boost=True, steer=-0.95)]
            + 2 * 4 * [SimpleControllerState(throttle=1, jump=True, boost=True)]
            + 1 * 4 * [SimpleControllerState(throttle=1, boost=True)]
            + 1 * 4 * [SimpleControllerState(throttle=1, yaw=0.8, pitch=-0.7, jump=True, boost=True)]
            + 13 * 4 * [SimpleControllerState(throttle=1, pitch=1, boost=True)]
            + 10 * 4 * [SimpleControllerState(throttle=1, roll=1, pitch=0.5)]
            )

KICKOFF_NUMPYOR = np.array([
    [scs.throttle, scs.steer, scs.pitch, scs.yaw, scs.roll, scs.jump, scs.boost, scs.handbrake]
    for scs in KICKOFF_CONTROLSOR
])

class RLGymExampleBot(BaseAgent):
    def __init__(self, name, team, index):
        super().__init__(name, team, index)

        # FIXME Hey, botmaker. Start here:
        # Swap the obs builder if you are using a different one, RLGym's AdvancedObs is also available
        self.obs_builder = AdvancedObsPadder(expanding=True)
        self.kickoff_obs = AdvancedObs()
        # Swap the action parser if you are using a different one, RLGym's Discrete and Continuous are also available
        self.act_parser = LookupAction()
        # Your neural network logic goes inside the Agent class, go take a look inside src/agent.py
        self.agent = Agent()
        # Adjust the tickskip if your agent was trained with a different value
        self.tick_skip = 6

        self.game_state: GameState = None
        self.controls = None
        self.action = None
        self.update_action = True
        self.ticks = 0
        self.cur_tick = 0
        self.prev_time = 0
        self.expected_teammates = 0
        self.expected_opponents = 1
        self.current_obs = None
        self.gamemode = "gameplay"
        self.kickoff_seq = None
        print(f'{self.name} Ready - Index:', index)

    def initialize_agent(self):
        # Initialize the rlgym GameState object now that the game is active and the info is available
        self.game_state = GameState(self.get_field_info())
        self.ticks = self.tick_skip  # So we take an action the first tick
        self.prev_time = 0
        self.controls = SimpleControllerState()
        self.action = np.zeros(8)
        self.current_obs = None
        self.cur_tick = 0
        self.kickoff_index = -1
        self.update_action = True
        self.ko_diag_array = np.array([
        [1, 0, 0, 0, 0,0,1,0], #0
        [1, 0, 0, 0, 0,0,1,0],
        [1, 0, 0, 0, 0,0,1,0],
        [1, 0, 0, 0, 0,0,1,0],
        [1, 0,-1, 0, 1,0,1,0],
        [1, 0,-1, 0, 1,0,1,0],
        [1, 0,-1, 0, 1,0,1,0],
        [1,-1,-1, 0, 1,0,1,0],
        [1,-1,-1,-1, 1,1,1,0],
        [1, 0,-1,-1, 1,0,1,0],
        [1, 0,-1, 0, 1,1,1,0], #10
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 0, 1,0,1,0],
        [1, 0, 1, 1, 1,0,1,0], #20
        [1, 0, 1, 1, 1,0,1,0],
        [1, 0, 1, 1, 1,0,1,0],
        [1, 0, 1, 1, 1,0,1,0],
        [1, 0, 1, 1, 1,0,0,0],
        [1, 0, 1, 1, 1,0,0,0],
        [1, 0, 1, 1, 1,0,0,0],
        [1, 0, 0, 0, 0,0,0,0],
        [1, 0, 0,-1, 0,0,0,0],
        [1,-1, 0,-1, 0,0,0,0],
        [1,-1, 0,-1, 0,0,0,0], #30
        [1,-1, 0, 0, 0,0,0,0],
        [1, 0, 0, 0, 0,0,0,0],
    ])
        self.kickoff_time = 0
        self.ticks2 = -1
        self.kkpos = "center"
        self.kickoff_seq = None

    def reshape_state(self, gamestate, player, opponents, allies):
        closest_op = min(opponents, key=lambda p: np.linalg.norm(self.game_state.ball.position - p.car_data.position))
        self.game_state.players = [player, closest_op]

    def get_output(self, packet: GameTickPacket) -> SimpleControllerState:
        if self.tick_skip == 6 and (packet.game_ball.physics.location.x == 0 and packet.game_ball.physics.location.y == 0):
            self.tick_skip = 4
            self.ticks = 0
        elif self.tick_skip == 4 and (packet.game_ball.physics.location.x == 0 and packet.game_ball.physics.location.y == 0) != True:
            self.tick_skip = 6
            self.ticks = 0

        cur_time = packet.game_info.seconds_elapsed
        delta = cur_time - self.prev_time
        self.prev_time = cur_time

        ticks_elapsed = round(delta * 120)
        self.ticks += ticks_elapsed
        self.game_state.decode(packet, ticks_elapsed)

        if self.update_action == True and len(self.game_state.players) > self.index:
            self.update_action = False

            player = self.game_state.players[self.index]
            teammates = [p for p in self.game_state.players if p.team_num == self.team and p != player]
            opponents = [p for p in self.game_state.players if p.team_num != self.team]

            if len(opponents) != self.expected_opponents or len(teammates) != self.expected_teammates:
                self.reshape_state(self.game_state, player, opponents, teammates)
            
            if packet.game_ball.physics.location.x == 0 and packet.game_ball.physics.location.y == 0:
                obs = self.kickoff_obs.build_obs(player, self.game_state, self.action)
            else:
                obs = self.obs_builder.build_obs(player, self.game_state, self.action)

            self.action = self.agent.act(obs, packet)

        if self.ticks >= self.tick_skip - 1:
            self.update_controls(self.action)

        if self.ticks >= self.tick_skip:
            self.ticks = 0
            self.update_action = True

        #self.maybe_do_kickoff(packet, ticks_elapsed)

        return self.controls

    def maybe_do_kickoff(self, packet, ticks_elapsed):
        if packet.game_info.is_kickoff_pause:
            if self.kickoff_index >= 0:
                self.kickoff_index += round(ticks_elapsed)
            elif self.kickoff_index == -1:
                is_kickoff_taker = False
                ball_pos = np.array([packet.game_ball.physics.location.x, packet.game_ball.physics.location.y])
                positions = np.array([[car.physics.location.x, car.physics.location.y]
                                      for car in packet.game_cars[:packet.num_cars]])
                distances = np.linalg.norm(positions - ball_pos, axis=1)
                if abs(distances.min() - distances[self.index]) <= 10:
                    is_kickoff_taker = True
                    indices = np.argsort(distances)
                    for index in indices:
                        if abs(distances[index] - distances[self.index]) <= 10 \
                                and packet.game_cars[index].team == self.team \
                                and index != self.index:
                            if self.team == 0:
                                is_left = positions[index, 0] < positions[self.index, 0]
                            else:
                                is_left = positions[index, 0] > positions[self.index, 0]
                            if not is_left:
                                is_kickoff_taker = False  # Left goes

                self.kickoff_index = 0 if is_kickoff_taker else -2

            if 0 <= self.kickoff_index < len(KICKOFF_NUMPYN) \
                    and packet.game_ball.physics.location.y == 0:
                self.get_kickoff_pos()
                if self.kkpos == "Offset L":
                    action = KICKOFF_NUMPYOL[self.kickoff_index]
                elif self.kkpos == "Offset R":
                    action = KICKOFF_NUMPYOR[self.kickoff_index]
                else:
                    action = KICKOFF_NUMPYN[self.kickoff_index]
                self.action = action
                self.update_controls(self.action)
        else:
            self.kickoff_index = -1

    def update_controls(self, action):
        self.controls.throttle = action[0]
        self.controls.steer = action[1]
        self.controls.pitch = action[2]
        self.controls.yaw = action[3]
        self.controls.roll = action[4]
        self.controls.jump = action[5] > 0
        self.controls.boost = action[6] > 0
        self.controls.handbrake = action[7] > 0

    def Length(self, vec):
	    return math.sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z)

    def get_kickoff_pos(self):
        if 2046 <= abs(self.game_state.players[self.team].car_data.position[0]) <= 2050 and 2558 <= abs(self.game_state.players[self.team].car_data.position[1]) <= 2562 and abs(self.game_state.players[self.team].car_data.linear_velocity[0]) <= 30:
            if self.game_state.players[0].car_data.position[0] > 0:
                self.kkpos = 'Diagonal L'
            elif self.game_state.players[0].car_data.position[0] < 0:
                self.kkpos = 'Diagonal R'
        elif 254 <= abs(self.game_state.players[self.team].car_data.position[0]) <= 258 and 3838 <= abs(self.game_state.players[self.team].car_data.position[1]) <= 3842 and abs(self.game_state.players[self.team].car_data.linear_velocity[0]) <= 30:
            if self.game_state.players[0].car_data.position[0] > 0:
                self.kkpos = 'Offset L'
            elif self.game_state.players[0].car_data.position[0] < 0:
                self.kkpos = 'Offset R'
        elif abs(self.game_state.players[self.team].car_data.position[0]) <= 2 and 4606 <= abs(self.game_state.players[self.team].car_data.position[1]) <= 4610 and abs(self.game_state.players[self.team].car_data.linear_velocity[0]) <= 30:
            self.kkpos = 'Center'
 
