from stable_baselines3 import PPO
from rlbot.agents.base_agent import BaseAgent, SimpleControllerState
import numpy as np
import pathlib
from rlgym_tools.extra_action_parsers.lookup_act import LookupAction
from rlgym.utils.action_parsers.discrete_act import DiscreteAction
import sys

class Agent:
    def __init__(self):
        _path = pathlib.Path(__file__).parent.resolve()
        custom_objects = {
            "lr_schedule": 0.00001,
            "clip_range": .02,
            "n_envs": 1,
            "device": "cpu"
        }

        self.actor = PPO.load(str(_path) + '/models/Aurora_G', custom_objects=custom_objects)
        self.kickoff_model = PPO.load(str(_path) + '/models/Aurora_K', custom_objects=custom_objects)
        self.parser = LookupAction()
        self.kickoff_parser = DiscreteAction()

    def act(self, state, packet):
        if packet.game_ball.physics.location.x == 0 and packet.game_ball.physics.location.y == 0:
            action = self.kickoff_model.predict(state, deterministic=True)
            x = self.kickoff_parser.parse_actions(action[0], state)
            return x[0]
        action = self.actor.predict(state, deterministic=True)
        x = self.parser.parse_actions(action[0], state)

        return x
