from rlbot.agents.base_agent import BaseAgent, SimpleControllerState
from rlbot.utils.structures.game_data_struct import GameTickPacket

from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent.parent.resolve()))
sys.path.append(str((Path(__file__).parent).resolve()))
from Bubbly.bot import BubblyClass

sys.path.append(str((Path(__file__).parent  / "Omus").resolve()))
from Omus.bot import Omus

class BubblyOmus(BubblyClass, Omus):
    
    def __init__(self, name, team, index):
        BubblyClass.__init__(self, name, team, index)
        Omus.__init__(self,name, team, index)

    def initialize_agent(self):
        BubblyClass.initialize_agent(self)
        Omus.initialize_agent(self)


    def get_output(self, packet: GameTickPacket) -> SimpleControllerState:
        if packet.game_ball.physics.location.x != 0 or packet.game_ball.physics.location.y != 0:
            return BubblyClass.get_output(self, packet)
        else:
            return Omus.get_output(self, packet)
